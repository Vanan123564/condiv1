#pragma once

#define HTTP_SERVER "116.103.229.131"
#define HTTP_PORT 80

#define TFTP_SERVER "116.103.229.131"
